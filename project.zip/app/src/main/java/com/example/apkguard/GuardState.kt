package com.example.apkguard

object GuardState {
    // Skanerdan ilovani o'chirishda shu vaqtgacha bloklamaymiz
    @Volatile var allowUntil = 0L
}
