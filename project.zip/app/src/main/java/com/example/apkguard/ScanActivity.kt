package com.example.apkguard

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class ScanActivity : Activity() {

    private data class Item(
        val title: String, val sub: String, val level: Int,
        val pkg: String? = null, val file: File? = null
    )

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView

    private val trustedInstallers = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps",
        "com.huawei.appmarket", "com.xiaomi.mipicks", "com.heytap.market",
        "com.bbk.appstore", "com.amazon.venezia"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Skanerlash"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        summary = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.parseColor("#BBBBBB"))
            setPadding(0, dp(8), 0, dp(16))
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1220"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
            addView(title); addView(summary)
            addView(scroll, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        startScan()
    }

    private fun startScan() {
        summary.text = "Skanerlanmoqda..."
        list.removeAllViews()
        Thread {
            val items = mutableListOf<Item>()
            val checked = scanApps(items)
            val hasFileAccess = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
            if (hasFileAccess) {
                walk(Environment.getExternalStorageDirectory(), 0, items)
            }
            runOnUiThread { render(items.sortedByDescending { it.level }, checked, hasFileAccess) }
        }.start()
    }

    private fun scanApps(out: MutableList<Item>): Int {
        val pm = packageManager
        var checked = 0
        for (ai in pm.getInstalledApplications(0)) {
            if (ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            checked++
            val installer = installerOf(ai.packageName)
            if (installer in trustedInstallers) continue
            val risky = riskyCount(ai.packageName)
            val level = if (risky >= 2) 2 else 1
            val sub = "Rasmiy do'kondan emas" +
                if (risky > 0) " • xavfli ruxsatlar: $risky" else ""
            out.add(Item(pm.getApplicationLabel(ai).toString(), sub, level, pkg = ai.packageName))
        }
        return checked
    }

    @Suppress("DEPRECATION")
    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30)
            packageManager.getInstallSourceInfo(pkg).installingPackageName
        else packageManager.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    private fun riskyCount(pkg: String): Int {
        val pi = try {
            packageManager.getPackageInfo(
                pkg, PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES)
        } catch (e: Exception) { return 0 }
        val perms = pi.requestedPermissions?.toSet() ?: emptySet()
        var c = 0
        if ("android.permission.READ_SMS" in perms || "android.permission.RECEIVE_SMS" in perms) c++
        if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) c++
        if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms) c++
        val bad = setOf(
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
            "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
        )
        if (pi.services?.any { it.permission in bad } == true) c++
        return c
    }

    private fun walk(dir: File, depth: Int, out: MutableList<Item>) {
        if (depth > 6) return
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (depth == 0 && f.name == "Android") continue
                walk(f, depth + 1, out)
            } else if (f.name.endsWith(".apk", ignoreCase = true)) {
                out.add(Item(f.name, "${f.parent} • ${f.length() / 1024 / 1024} MB", 2, file = f))
            }
        }
    }

    private fun render(items: List<Item>, checked: Int, hasFileAccess: Boolean) {
        list.removeAllViews()
        val danger = items.count { it.level == 2 }
        val warn = items.count { it.level == 1 }

        if (!hasFileAccess) {
            list.addView(card("APK fayllarni qidirish uchun ruxsat kerak",
                "\"Barcha fayllarga ruxsat\"ni yoqing", 1,
                "Ruxsat berish") {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            })
        }

        if (items.isEmpty() && hasFileAccess) {
            summary.text = "$checked ta ilova tekshirildi. Hammasi toza ✓"
            summary.setTextColor(Color.parseColor("#66BB6A"))
            return
        }
        summary.text = "$checked ta ilova tekshirildi.  Xavfli: $danger   Shubhali: $warn"
        summary.setTextColor(if (danger > 0) Color.parseColor("#EF5350") else Color.parseColor("#FFA726"))

        for (it in items) {
            val action = if (it.file != null) "Faylni o'chirish" else "Ilovani o'chirish"
            list.addView(card(it.title, it.sub, it.level, action) {
                if (it.file != null) { it.file.delete(); startScan() }
                else {
                    GuardState.allowUntil = System.currentTimeMillis() + 90_000
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${it.pkg}")))
                }
            })
        }
    }

    private fun card(title: String, sub: String, level: Int, action: String, onClick: () -> Unit): LinearLayout {
        val color = if (level == 2) "#EF5350" else "#FFA726"
        val fill = if (level == 2) "#2E1517" else "#2E2412"
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor(fill))
                setStroke(dp(2), Color.parseColor(color))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(12)) }
            addView(TextView(context).apply {
                text = title; textSize = 18f
                setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(context).apply {
                text = sub; textSize = 14f
                setTextColor(Color.parseColor("#BBBBBB"))
                setPadding(0, dp(4), 0, dp(10))
            })
            addView(Button(context).apply {
                text = action
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor(color))
                }
                gravity = Gravity.CENTER
                setOnClickListener { onClick() }
            })
        }
    }
}
