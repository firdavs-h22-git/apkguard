package com.example.apkguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class GuardAccessibilityService : AccessibilityService() {

    // APK o'rnatuvchi oyna paketlari (turli brendlarda har xil)
    private val installerPackages = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.miui.packageinstaller",
        "com.oppo.packageinstaller",
        "com.coloros.packageinstaller",
        "com.vivo.packageinstaller"
    )

    private var lastBlock = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in installerPackages) blockInstall()
    }

    private fun blockInstall() {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 1500) return // ketma-ket takrorlanmasin
        lastBlock = now

        performGlobalAction(GLOBAL_ACTION_HOME) // o'rnatuvchi oynani yopadi
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(BlockActivity.EXTRA_REASON, "APK o'rnatish taqiqlandi!")
        )
    }

    override fun onInterrupt() {}
}
