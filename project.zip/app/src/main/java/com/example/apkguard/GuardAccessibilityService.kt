package com.example.apkguard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class GuardAccessibilityService : AccessibilityService() {

    private val installerPackages = setOf(
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.samsung.android.packageinstaller",
        "com.miui.packageinstaller",
        "com.oppo.packageinstaller",
        "com.coloros.packageinstaller",
        "com.vivo.packageinstaller"
    )

    private val handler = Handler(Looper.getMainLooper())
    private var lastBlock = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in installerPackages) blockInstall()
    }

    private fun blockInstall() {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 1500) return
        lastBlock = now

        // BACK o'rnatuvchi oynani yopadi (yopilgach operativkadan ham ketadi)
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_HOME)
            startActivity(
                Intent(this, BlockActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_NO_HISTORY or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                    )
                    .putExtra(BlockActivity.EXTRA_REASON, "APK o'rnatish taqiqlandi!")
            )
        }, 250)
    }

    override fun onInterrupt() {}
}
