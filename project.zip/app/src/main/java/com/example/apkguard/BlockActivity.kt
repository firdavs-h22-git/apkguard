package com.example.apkguard

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {

    companion object { const val EXTRA_REASON = "reason" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)

        val reason = intent.getStringExtra(EXTRA_REASON) ?: "Xavfli harakat taqiqlandi!"

        val title = TextView(this).apply {
            text = "⛔ TO'XTANG!"
            textSize = 36f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val msg = TextView(this).apply {
            text = "$reason\n\nBu virus bo'lishi mumkin. Telegramdan kelgan APK fayllarni o'rnatmang."
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val btn = Button(this).apply {
            text = "Tushunarli"
            textSize = 22f
            setOnClickListener { finishAndRemoveTask() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#C62828"))
            addView(title); addView(msg); addView(btn)
        })
    }
}
