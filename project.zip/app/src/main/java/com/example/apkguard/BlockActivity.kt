package com.example.apkguard

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {

    companion object { const val EXTRA_REASON = "reason" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)

        val reason = intent.getStringExtra(EXTRA_REASON) ?: "Xavfli harakat taqiqlandi!"

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_shield)
            layoutParams = LinearLayout.LayoutParams(dp(160), dp(160))
        }
        ObjectAnimator.ofPropertyValuesHolder(
            icon,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f)
        ).apply {
            duration = 700
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }

        val title = TextView(this).apply {
            text = "TO'XTANG!"
            textSize = 38f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        val msg = TextView(this).apply {
            text = "$reason\n\nBu virus bo'lishi mumkin.\nTelegramdan kelgan APK fayllarni o'rnatmang."
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(16), dp(24), dp(32))
        }
        val btn = Button(this).apply {
            text = "Tushunarli"
            textSize = 22f
            setTextColor(Color.parseColor("#B71C1C"))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.WHITE)
            }
            setPadding(dp(48), dp(14), dp(48), dp(14))
            setOnClickListener { finishAndRemoveTask() }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#B71C1C"), Color.parseColor("#3E0808"))
            )
            addView(icon); addView(title); addView(msg); addView(btn)
        })
    }

    // Oyna yopilganda operativ xotira (recents) ro'yxatida qolmasin
    override fun onStop() {
        super.onStop()
        finishAndRemoveTask()
    }
}
