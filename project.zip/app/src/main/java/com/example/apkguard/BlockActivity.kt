package com.example.apkguard

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {

    companion object { const val EXTRA_REASON = "reason" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)

        val reason = intent.getStringExtra(EXTRA_REASON) ?: "O'rnatish bekor qilindi"

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_shield)
            layoutParams = LinearLayout.LayoutParams(dp(110), dp(110))
        }
        ObjectAnimator.ofPropertyValuesHolder(
            icon,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.08f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.08f)
        ).apply {
            duration = 800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }

        val brand = TextView(this).apply {
            text = "APK Guard"
            textSize = 18f
            setTextColor(Color.parseColor("#FF8A2B"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        val title = TextView(this).apply {
            text = reason
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val msg = TextView(this).apply {
            text = "Ilova o'rnatishga ruxsat berilmadi. Yuklangan fayl virus yoki zararli " +
                "dastur bo'lishi mumkin, shuning uchun himoya o'rnatishni to'xtatdi.\n\n" +
                "Ishonchli ilova bo'lsa, oila a'zolaringizdan so'rang."
            textSize = 16f
            setTextColor(Color.parseColor("#C9C2BC"))
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(20))
        }
        val btn = Button(this).apply {
            text = "Tushundim"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(Color.parseColor("#2ED15C"))
            }
            setOnClickListener { finishAndRemoveTask() }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#382A22"))
            }
            addView(icon); addView(brand); addView(title); addView(msg)
            addView(btn, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        }

        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000")) // xira fon
            setPadding(dp(24), 0, dp(24), 0)
            addView(card, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER))
        })
    }

    // Oyna yopilganda operativ xotirada qolmasin
    override fun onStop() {
        super.onStop()
        finishAndRemoveTask()
    }
}
