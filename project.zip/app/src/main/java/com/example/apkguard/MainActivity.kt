package com.example.apkguard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var icon: ImageView
    private lateinit var status: TextView
    private lateinit var btn: Button
    private lateinit var info: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        icon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(150), dp(150))
        }
        val title = TextView(this).apply {
            text = "APK Guard"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        }
        status = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(12), dp(32), dp(28))
        }
        btn = Button(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#FF7A1A"))
            }
            setPadding(dp(36), dp(12), dp(36), dp(12))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val scanBtn = Button(this).apply {
            text = "Skanerlash"
            textSize = 18f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.parseColor("#2A3050"))
            }
            setPadding(dp(36), dp(12), dp(36), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ScanActivity::class.java))
            }
        }

        info = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#666B7A"))
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), 0)
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F1220"))
            addView(icon); addView(title); addView(status); addView(btn); addView(scanBtn); addView(info)
        })
    }

    override fun onResume() {
        super.onResume()
        info.text = getSharedPreferences("guard", MODE_PRIVATE).getString("last", null)
            ?.let { "Oxirgi o'rnatuvchi oyna:\n$it" } ?: ""
        if (isGuardEnabled()) {
            icon.setImageResource(R.drawable.ic_shield_ok)
            status.text = "Himoya yoqilgan.\nQurilmangiz himoyada."
            status.setTextColor(Color.parseColor("#66BB6A"))
            btn.text = "Sozlamalarni ochish"
        } else {
            icon.setImageResource(R.drawable.ic_shield)
            status.text = "Himoya o'chiq!\n\"Maxsus imkoniyatlar\"dan APK Guard ni yoqing."
            status.setTextColor(Color.parseColor("#EF5350"))
            btn.text = "Himoyani yoqish"
        }
    }

    private fun isGuardEnabled(): Boolean {
        val s = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.contains("$packageName/${GuardAccessibilityService::class.java.name}")
    }
}
